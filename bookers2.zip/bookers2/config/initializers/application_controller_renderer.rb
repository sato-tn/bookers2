# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '4affa2d436a8a353a425324578e97d4f9e31f9949290ecb962844ecae56307c00fe658ca978a5dc7f1939f797a7c1870d61689412ff31c9e3c0e6d49c58f064f'